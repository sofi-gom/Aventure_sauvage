#include "roomDynamicallyIlluminated.h"

void RoomDynamicallyIlluminated::toggleIllumination() {
	illumination = !illumination;
}

bool RoomDynamicallyIlluminated::getIllumination() {
	return illumination;
}