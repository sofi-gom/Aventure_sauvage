#pragma once
#include "room_.h"
using namespace std;

class RoomDynamicallyIlluminated:public Room {
public:
	RoomDynamicallyIlluminated(string name, string description, bool illumination) :Room(name, description) { this->illumination = illumination; }
	bool getIllumination();

	void toggleIllumination()override;
private:
	bool illumination;
};
