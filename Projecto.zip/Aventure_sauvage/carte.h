#pragma once
#include <iostream>
#include "room_.h"

class Map {
public:

    Map();
    void nextRoom();

private:

    Room* shop = new Room("Little shop", "Here you can buy little gifts");
    Room* entrance = new Room("Entrance", "Here starts the game");
    Room* desertAnimals = new Room("Desert animal section", "Here you can find snakes! ");
    Room* forestAnimals = new Room("Forest animal area", "Here you can find trees and a lake.");
    Room* tropicalAnimals = new Room("Tropical animal area", "Here you can find monkeys. ");
    Room* restrictedCactusZone = new Room("Restricted cactus zone", "Here you can find cactus. ");
    Room* restrictedLionFeedingZone = new Room("Restricted lion feeding zone", "Here you can find lions. ");
    Room* currentRoom;
};


