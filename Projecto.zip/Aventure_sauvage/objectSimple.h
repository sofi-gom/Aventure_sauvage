#pragma once
#include <iostream>
#include "assert.h"
#include "room_.h"

using namespace std;

typedef enum {
	simple,
	illumination,
	unlock
}objectType;



class ObjectSimple {
public:

	ObjectSimple(string name, string description, string use);

	string getName();
	string getDescription();
	string getUse();
	virtual objectType getType();
	//virtual void useObject(Room* room) {}


private:
	string name;
	string description;
	string use;
	Room* room;
};



