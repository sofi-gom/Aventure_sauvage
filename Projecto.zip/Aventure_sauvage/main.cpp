
#include <iostream>
#include "carte.h"

using namespace std;


int main() {

    Map map = Map();
     
    while (true) {
        map.nextRoom();
    }
    return 0;
}

///REVISAR en room.H Y OBJECT.H