#pragma once
#include "objectSimple.h"
#include "room_.h"

using namespace std;

class ObjectLightControl : public ObjectSimple {
public:
	ObjectLightControl(string name, string description, string use, bool iluminationObject) :ObjectSimple(name, description, use) { this->iluminationObject = iluminationObject; }
	bool getIluminationObject();
	objectType getType()override;
	/*void useObject(Room* room) {
		cout << "funciona "<< room->getName() << endl;
	}*/
private:
	bool iluminationObject;
};


