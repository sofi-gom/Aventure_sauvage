#pragma once
#include <stdio.h>
#include <iostream>
#include<string>
#include <algorithm>
#include "connection.h"

#include <vector>

#define SOUTH_WORD "sur"
#define SOUTH_LETTER "s"
#define NORTH_WORD "norte"
#define NORTH_LETTER "n"
#define EAST_WORD "este"
#define EAST_LETTER "e"
#define WEST_WORD "oeste"
#define WEST_LETTER "o"
#define USE "use"


using namespace std;

class Room {
public:
    Room(string name, string description);
    vector < ObjectSimple*> objects;
    Room* N;
    Room* E;
    Room* S;
    Room* W;

    string getName();
    string getUserInput();
    string getDescription();
    //bool getIllumination();
    ///REVISAR
    bool allowRoomAccess(bool);
    void setIllumination(bool);
    void printName();
    void printDescription();
    void printObjects();
    Room* showDoors();
    virtual void toggleIllumination();

    private:
        

        void eraseSubstring(std::string& mystring, const std::string& toErase);
        Room* validDirection(string word, string  letter, Room* room);
        string userInput;
        string name;
        string description;
        //bool illumination;
};



