#include "objectUnlock.h"

objectType ObjectUnlock::getType() {
	return unlock;
}

bool ObjectUnlock::getRestrictedZoneOpener() {
	return openHiddenZone;
}