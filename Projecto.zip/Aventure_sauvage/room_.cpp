#include "room_.h"


void Room::toggleIllumination() {

}

Room::Room(string name, string description) {
    this->name = name;
    this->description = description;
}
///REVISAR
bool Room::allowRoomAccess(bool allow) {
    if (allow == true) {
        return true;
    }return false;
}

void Room::printName() {
    cout << "-----" << name << "-----" << "\n";
}

string Room::getName() {
    return name;
}

string Room::getUserInput() {
    return userInput;
}

string Room::getDescription() {
    return description;
}

/*bool Room::getIllumination() {
    return illumination;
}*/

/*void Room::setIllumination(bool illumination) {
    this->illumination = illumination;
}*/

void Room::printObjects() {
    cout << "Object list: " << endl;
    for (int i = 0; i < objects.size(); i++) cout << " " << objects[i]->getName() << " " << objects[i]->getType() << endl;
}

void Room::printDescription() {
    cout << description << "\n";
    printObjects();
    cout << "These are the surrounding rooms: \n";
    if (N != NULL) {
        cout << N->name << " [" << NORTH_LETTER << "]\n";
    }
    if (S != NULL) {
        cout << S->name << " [" << SOUTH_LETTER << "]\n";
    }
    if (E != NULL) {
        cout << E->name << " [" << EAST_LETTER << "]\n";
    }
    if (W != NULL) {
        cout << W->name << " [" << WEST_LETTER << "]\n";
    }
    cout << "Choose a direction to enter another room. \n";
}

Room* Room::validDirection(string word, string  letter, Room* room) {
    if (userInput.compare(letter) == 0 || userInput.compare(word) == 0) {
        if (room == NULL) {
            cout << "Sorry! No rooms in that direction.\n";
            return this;
        }
        else {
            return room;
        }
    }
    else return NULL;
}

Room* Room::showDoors() {
    //lowercase input
    getline(cin, userInput);
    for_each(userInput.begin(), userInput.end(), [](char& c) {
        c = tolower(c);
        });
    //move to another room
    Room* auxRom = validDirection(NORTH_LETTER, NORTH_WORD, N);
    if (auxRom != NULL) return auxRom;
    auxRom = validDirection(SOUTH_LETTER, SOUTH_WORD, S);
    if (auxRom != NULL) return auxRom;
    auxRom = validDirection(EAST_LETTER, EAST_WORD, E);
    if (auxRom != NULL) return auxRom;
    auxRom = validDirection(WEST_LETTER, WEST_WORD, W);
    if (auxRom != NULL) return auxRom;

    if (userInput.find(USE) != string::npos) {

        if (userInput.compare(USE) == 0) {
            cout << "Use what?" << endl;
        }
        else {
            eraseSubstring(userInput, "use ");
            int objectIndex = -1;
            int iluminationObjectIndex = -1;
            int unlockObjectIndex = -1;

            //looks for object
            for (int i = 0; i < objects.size(); i++) {
                if (objects[i]->getName().find(userInput) != string::npos) {
                    objectIndex = i;
                    break;
                }
            }



            if (objectIndex == -1) {
                cout << "Object not found" << endl;
            }
            else {
                cout << objects[objectIndex]->getUse() << endl;
                objects[objectIndex]->getUse();
            }
        }
        return NULL;
    }

    else if (userInput.find("look") != string::npos) {

        if (userInput.compare("look") == 0) {
            printName();
            printDescription();
        }
        else {
            eraseSubstring(userInput, "look ");
            cout << "buscar objeto " << userInput << endl;

            int objectIndex = -1;

            for (int i = 0; i < objects.size(); i++) {
                if (objects[i]->getName().find(userInput) != string::npos) {
                    objectIndex = i;
                    break;

                }
            }
            if (objectIndex == -1) {
                cout << "objeto no encontrado" << endl;
            }
            else {
                cout << objects[objectIndex]->getDescription() << endl;
            }
        }
        return NULL;
    }
    else {
        cout << "Invalid entry/I don't know that. \n\n";
        return this;
    }
}

void Room::eraseSubstring(std::string& myString, const std::string& eraseThis)
{//Function from StackOverflow
    // Search if what I want to erase is in the string
    size_t pos = myString.find(eraseThis);
    if (pos != std::string::npos)
    {
        // Erase eraseThis from string
        myString.erase(pos, eraseThis.length());
    }
}