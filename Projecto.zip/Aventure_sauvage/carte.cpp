#include "carte.h"
#include "objectSimple.h"
#include "objectUnlock.h"
#include "objectLightControl.h"


using namespace std;

Map::Map() {
    printf("\033[36m***Fun Game***\n\n");
    entrance->W = shop;
    entrance->N = desertAnimals;

    ///objetos de la tiendita
    shop->objects.push_back(new ObjectSimple("un piano", "el piano tiene muchas teclas", "estas tocando una cancion en el piano"));
    shop->objects.push_back(new ObjectSimple("un lapiz", "el lapiz tiene la punta rota", "estas escribiendo palabras con el lapiz"));
    shop->objects.push_back(new ObjectLightControl("un switch", "el switch va a prender la luz", "estas prendiendo la luz", false));

    //objetos de  animales del desierto
    desertAnimals->objects.push_back(new ObjectUnlock("una llave", "la llave es dorada", "la llave abre la puerta de la zona escondida de cactus", false));
    desertAnimals->objects.push_back(new ObjectSimple("una botella de agua", "la botella de agua no esta abierta", "te tomas el agua de la botella"));
    desertAnimals->objects.push_back(new ObjectLightControl("un switch", "el switch va a prender la luz", "estas prendiendo la luz", false));

    shop->E = entrance;
    desertAnimals->S = entrance;
    desertAnimals->E = forestAnimals;
    desertAnimals->N = tropicalAnimals;
    tropicalAnimals->S = desertAnimals;
    forestAnimals->W = desertAnimals;

    /*
    if(allowRoomAcces(true)) {
        restrictedCactusZone->E = desertAnimals;
        restrictedCactusZone->S = shop;
    }*/

    currentRoom = entrance;
}

void Map::nextRoom() {
    currentRoom->printName();
    currentRoom->printDescription();
    Room* moveFromRoom;
    do {
        moveFromRoom = currentRoom->showDoors();
        cout << endl;
    } while (moveFromRoom == NULL);
    currentRoom = moveFromRoom;
}