#pragma once
#include "objectSimple.h"
#include "room_.h"