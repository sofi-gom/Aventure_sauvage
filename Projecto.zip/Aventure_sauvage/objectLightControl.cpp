#include "objectLightControl.h"

objectType ObjectLightControl::getType() {
	return illumination;
}

bool ObjectLightControl::getIluminationObject() {
	return iluminationObject;
}